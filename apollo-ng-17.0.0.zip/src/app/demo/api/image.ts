export interface Image {
    previewImageSrc: string;
    thumbnailImageSrc: string;
    alt: string;
    title: string;
}
