import { Component } from '@angular/core';

@Component({
    templateUrl: './accessdenied.component.html'
})
export class AccessdeniedComponent { }