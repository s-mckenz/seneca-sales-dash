import { Component } from '@angular/core';

@Component({
    templateUrl: './help.component.html',
})
export class HelpComponent { }